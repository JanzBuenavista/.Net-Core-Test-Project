namespace Sprout.Payroll.Test
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;
    using System.Collections.Generic;

    public class EmployeeTypeTest
    {
        private ResponseModel _response = new ResponseModel();

        private static readonly EmployeeType bll = new EmployeeType();

        private static int uniqueEmployeeTypeId;

        [SetUp]
        public void Setup()
        {
            this.AddEmployeeType();
            this.GetEmployeeType();
            this.ModifyEmployeeType();
            this.GetAllEmployeeType();
            this.RemoveEmployeeType();
        }

        [Test]
        public void AddEmployeeType()
        {
            EmployeeTypeModel model = new EmployeeTypeModel();
            model.EmployeeTypeName = "REGULAR";
            model.Salary = 20000;
            model.Tax = 12;
            model.DailyRate = false;

            _response = bll.AddEmployeeType(model);

            List<EmployeeTypeModel> listData = new List<EmployeeTypeModel>();
            listData = new List<EmployeeTypeModel>();
            listData = JsonConvert.DeserializeObject<List<EmployeeTypeModel>>(
                JsonConvert.SerializeObject(_response.Data, Formatting.None)
            );

            uniqueEmployeeTypeId = listData[0].EmployeeTypeId;

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void ModifyEmployeeType()
        {

            EmployeeTypeModel model = new EmployeeTypeModel();
            model.EmployeeTypeId = uniqueEmployeeTypeId;
            model.EmployeeTypeName = "CONTRACTUAL";
            model.Salary = 500;
            model.Tax = 0;
            model.DailyRate = true;

            _response = bll.ModifyEmployeeType(model);

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void GetAllEmployeeType()
        {
            _response = bll.GetAllEmployeeType();

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void GetEmployeeType()
        {
            int employeeTypeId = uniqueEmployeeTypeId;
            _response = bll.GetEmployeeType(employeeTypeId);

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void RemoveEmployeeType()
        {
            int employeeTypeId = uniqueEmployeeTypeId;
            _response = bll.RemoveEmployeeType(employeeTypeId);

            Assert.AreEqual(1, _response.Status);
        }
    }
}