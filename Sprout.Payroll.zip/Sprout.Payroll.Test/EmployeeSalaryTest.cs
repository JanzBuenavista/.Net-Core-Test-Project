﻿namespace Sprout.Payroll.Test
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;
    using System.Collections.Generic;

    public class EmployeeSalaryTest
    {
        private ResponseModel _response = new ResponseModel();

        private static readonly EmployeeSalary bll = new EmployeeSalary();

        private static int uniqueSalaryId;

        [SetUp]
        public void Setup()
        {
            this.AddSalary();
            this.GetSalary();
            this.ModifySalary();
            this.GetAllSalary();
            this.RemoveSalary();
        }

        [Test]
        public void AddSalary()
        {
            EmployeeSalaryModel model = new EmployeeSalaryModel();
            model.EmployeeId = 1;
            model.Days = 2;
            model.Amount = 6;
            model.EmployeeTypeId = 1;

            _response = bll.AddSalary(model);

            List<EmployeeSalaryModel> listData = new List<EmployeeSalaryModel>();
            listData = new List<EmployeeSalaryModel>();
            listData = JsonConvert.DeserializeObject<List<EmployeeSalaryModel>>(
                JsonConvert.SerializeObject(_response.Data, Formatting.None)
            );

            uniqueSalaryId = listData[0].EmployeeTypeId;

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void ModifySalary()
        {

            EmployeeSalaryModel model = new EmployeeSalaryModel();
            model.EmployeeSalaryId = uniqueSalaryId;
            model.EmployeeId = 1;
            model.Days = 3;
            model.Amount = 6653;
            model.EmployeeTypeId = 1;

            _response = bll.ModifySalary(model);

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void GetAllSalary()
        {
            _response = bll.GetAllSalary();

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void GetSalary()
        {
            int employeeSalaryId = uniqueSalaryId;
            _response = bll.GetSalary(employeeSalaryId);

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void RemoveSalary()
        {
            int employeeSalaryId = uniqueSalaryId;
            _response = bll.RemoveSalary(employeeSalaryId);

            Assert.AreEqual(1, _response.Status);
        }
    }
}
