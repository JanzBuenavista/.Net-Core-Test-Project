﻿namespace Sprout.Payroll.Test
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;
    using System.Collections.Generic;

    public class EmployeeTest
    {
        private ResponseModel _response = new ResponseModel();

        private static readonly Employee bll = new Employee();

        private static int uniqueEmployeeId;

        [SetUp]
        public void Setup()
        {
            this.AddEmployee();
            this.GetEmployee();
            this.ModifyEmployee();
            this.GetAllEmployee();
            this.RemoveEmployee();
        }

        [Test]
        public void AddEmployee()
        {
            EmployeeModel model = new EmployeeModel();
            model.Name = "JOHN";
            model.Birthdate = "04/10/2021";
            model.TIN = "122345";
            model.EmployeeTypeId = 1;

            _response = bll.AddEmployee(model);

            List<EmployeeModel> listData = new List<EmployeeModel>();
            listData = new List<EmployeeModel>();
            listData = JsonConvert.DeserializeObject<List<EmployeeModel>>(
                JsonConvert.SerializeObject(_response.Data, Formatting.None)
            );

            uniqueEmployeeId = listData[0].EmployeeTypeId;

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void ModifyEmployee()
        {

            EmployeeModel model = new EmployeeModel();
            model.EmployeeTypeId = uniqueEmployeeId;
            model.Name = "JAMES";
            model.Birthdate = "06/15/2021";
            model.TIN = "122345";
            model.EmployeeTypeId = 1;

            _response = bll.ModifyEmployee(model);

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void GetAllEmployee()
        {
            _response = bll.GetAllEmployee();

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void GetEmployee()
        {
            int employeeId = uniqueEmployeeId;
            _response = bll.GetEmployee(employeeId);

            Assert.AreEqual(1, _response.Status);
        }

        [Test]
        public void RemoveEmployee()
        {
            int employeeId = uniqueEmployeeId;
            _response = bll.RemoveEmployee(employeeId);

            Assert.AreEqual(1, _response.Status);
        }
    }
}
