﻿using System.Data;

namespace Sprout.Payroll.Portal.Models
{
    /// <summary>
    /// Model for Response
    /// </summary>
    public class ResponseModel
    {
        /// <summary>
        /// Gets or sets Status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// Gets or sets message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets data
        /// </summary>
        public object Data { get; set; }
    }
}
