﻿namespace Sprout.Payroll.Portal.Models.Config
{
    using System.Collections.Generic;
    public class AuthTokenModel
    {
        public string Token { get; set; }

        public bool Success { get; set; }

        public List<string> Errors { get; set; }
    }
}
