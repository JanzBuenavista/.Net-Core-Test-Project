﻿namespace Sprout.Payroll.Portal.Models.Config
{
    public class TokenModel
    {
        public string Secret { get; set; }
    }
}
