﻿namespace Sprout.Payroll.Portal.Models
{
    public class ConnectionModel
    {
        public int UserId { get; set; }

        public string Username { get; set; }
    }
}
