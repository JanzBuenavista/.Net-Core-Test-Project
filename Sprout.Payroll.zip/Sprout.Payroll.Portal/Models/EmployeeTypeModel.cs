﻿namespace Sprout.Payroll.Portal.Models
{
    public class EmployeeTypeModel
    {
        public int EmployeeTypeId { get; set; }

        public string EmployeeTypeName { get; set; }

        public double Salary { get; set; }

        public bool DailyRate { get; set; }

        public double Tax { get; set; }
    }
}
