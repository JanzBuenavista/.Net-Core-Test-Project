﻿namespace Sprout.Payroll.Portal.Models
{
    public class EmployeeSalaryModel
    {
        public int EmployeeSalaryId { get; set; }

        public int EmployeeId { get; set; }

        public int EmployeeTypeId { get; set; }

        public double Days { get; set; }

        public double Amount { get; set; }

        public EmployeeModel Employee { get; set; }
    }
}
