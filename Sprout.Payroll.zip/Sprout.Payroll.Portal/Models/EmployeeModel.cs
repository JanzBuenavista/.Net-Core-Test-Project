﻿namespace Sprout.Payroll.Portal.Models
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }

        public string Name { get; set; }

        public string Birthdate { get; set; }

        public string TIN { get; set; }

        public int EmployeeTypeId { get; set; }

        public EmployeeTypeModel EmployeeTypeDetail { get; set; }
    }
}
