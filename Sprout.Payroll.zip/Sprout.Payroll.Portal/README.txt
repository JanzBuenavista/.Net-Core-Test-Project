﻿Question: If we are going to deploy this on production, what do you think the next improvement
that you will prioritize next? This can be a feature, a tech debt, or an architectural
design?

Answer:
- add some fields to specific the month, year and period when creating or adding of employee salary
- this is to avoid adding duplicate employee salary
- if the fields has been added we can create a new feature to generate 13th month pay
- we can also create a function to buld upload employee salary using excel file