﻿$(document).ready(function () {
    $('.numbers-only').keypress(function (e) {
        var verified = (e.which == 8 || e.which == undefined || e.which == 0) ? null : String.fromCharCode(e.which).match(/[^0-9\.]/);
        if (verified) { e.preventDefault(); }
    });

    $('.alpha-only').keypress(function (e) {
        var verified = (e.which == 8 || e.which == undefined || e.which == 0) ? null : String.fromCharCode(e.which).match(/[^A-Za-z_\s]/);
        if (verified) { e.preventDefault(); }
    });
});

function ThousandsSeparators(num) {
    var num_parts = num.toString().split(".");
    num_parts[0] = num_parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return num_parts.join(".");
}

function IsEmpty(value) {
    if (value === null || value.toString().toLowerCase() === 'null' || value === '' || value.toString().toLowerCase() === undefined) {
        return true;
    } else {
        return false;
    }
}

function LoadingOpen() {
    $('body').prepend('<div class="loader-bg"></div><div class="loader-wrapper"><div class="loader"></div ></div >');
    setTimeout(function () {
        $('.loader-wrapper, .loader-bg').addClass('show');
    }, 10);
}

function LoadingClose() {
    $('.loader-wrapper, .loader-bg').removeClass('show');
    setTimeout(function () {
        $('.loader-wrapper, .loader-bg').remove();
    }, 200);
}

function hasNull(target) {

    for (var member in target) {
        if (target[member] === '' || target[member] === undefined) {
            return true;
        }
    }
    return false;
}