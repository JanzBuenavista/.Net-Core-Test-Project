﻿$(document).ready(function () {
    var salary = new Salary();
    salary.GetAllSalary();
    salary.GetAllEmployee();
    salary.InitializeEvents();
});

function Salary() {
    var salary = this;
    salary._salaryId = null;
    salary._tblSalary = null;

    this.InitializeEvents = function () {
        $('#txtSearchSalary').keyup(function (e) {
            if (e.which === 13) {
                salary._tblSalary.search($(this).val()).draw();
            }
            else {
                if ($(this).val().length < 1) {
                    salary._tblSalary.search($(this).val()).draw();
                }
            }
        });

        $('#btnAddSalary').click(function () {
            salary.ClearFields();
            $('#mdlSalary').modal('show');
            $('#mdlSalary').removeClass('update');
            $('#btnSubmitSalary').html('<i aria-hidden="true" class="fa fa-plus"></i> Add');
            $('#btnSubmitSalary').attr('btn-process', 'add');
        });

        $('#btnSubmitSalary').click(function () {
            let process = $(this).attr('btn-process');
            let salaryObj = {
                EmployeeId: $('#cmbEmployee').val(),
                Amount: $('#txtSalary').val(),
                Days: $('#txtDays').val()
            };

            if (process === 'add') {
                if (!hasNull(salaryObj)) {
                    salary.AddSalary(salaryObj);
                }
                else {
                    MaterialNotify('Please fill in all Fields', 'warning');
                }
            }
            else if (process === 'update') {
                if (!hasNull(salaryObj)) {
                    salaryObj.EmployeeSalaryId = salary._salaryId;
                    salary.ModifySalary(salaryObj);
                }
                else {
                    MaterialNotify('Please fill in all Fields', 'warning');
                }
            }
        });

        $("#cmbEmployee").unbind().change(function () {
            let empId = $(this).val();

            $(this).val(empId).selectpicker('refresh');
            salary.GetEmployee(empId);
        });

        $("#txtDays").unbind().keyup(function () {
            $('#txtSalary').val('');
        });

        $("#btnCalculate").unbind().click(function () {
            let salaryObj = {
                EmployeeId: $('#cmbEmployee').val(),
                Days: $('#txtDays').val()
            };

            if (!hasNull(salaryObj)) {
                salary.ComputeSalary(salaryObj);
            }
            else {
                MaterialNotify('Please fill in all Fields', 'warning');
            }
        });
    };

    this.ModifySalary = function (details) {
        LoadingOpen();
        $.post('../Salary/ModifySalary', { details: details }, function (response) {

            if (response.status === 1) {
                $('#mdlSalary').modal('hide');
                salary.GetAllSalary();
                MaterialNotify(response.message, 'success');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.AddSalary = function (details) {
        LoadingOpen();
        $.post('../Salary/AddSalary', { details: details }, function (response) {

            if (response.status === 1) {
                $('#mdlSalary').modal('hide');
                salary.GetAllSalary();
                MaterialNotify(response.message, 'success');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.GetAllSalary = function () {
        LoadingOpen();

        $.post('../Salary/GetAllSalary', function (response) {

            if (salary._tblSalary !== null) {
                salary._tblSalary.destroy();
            }

            if (response.status === 1) {
                salary._tblSalary = $('#tblSalary').DataTable({
                    "paging": true,
                    "info": false,
                    "sort": true,
                    "dom": 'rtip',
                    "data": response.data,
                    "order": [[0, "desc"]],
                    "columns": [
                        {
                            data: "employeeId",
                            render: function (data, type, row, meta) {
                                return '<div>' + row.employee.name + '</div>' +
                                    '<div class="nav-container"><a class="edit-salary" data-salary-id="' + row.employeeSalaryId + '" data-emp-id="' + row.employeeId + '" data-type-id="' + row.employeeTypeId + '" href="#">' +
                                    '<i aria-hidden="true" class="fa fa-edit"></i> Edit</a><a class="remove-salary" data-salary-id="' + row.employeeSalaryId + '" href="#">' +
                                    '<i aria-hidden="true" class="fa fa-trash"></i> Remove</a></div>';
                            }
                        },
                        {
                            data: "employeeTypeId",
                            render: function (data, type, row, meta) {
                                return '<span>' + row.employee.employeeTypeDetail.employeeTypeName + '</span>';
                            }
                        },
                        {
                            data: "days",
                            render: function (data, type, row, meta) {
                                if (!row.employee.employeeTypeDetail.dailyRate) {
                                    return "<span>" + data + " Day's of Absent</span>";
                                }
                                else {
                                    return "<span>" + data + " Day's of Work</span>";
                                }
                            }
                        },
                        {
                            data: "amount",
                            render: function (data, type, row, meta) {
                                return '<span>' + ThousandsSeparators((Math.round(data * 100) / 100).toFixed(2)) + '</span>';
                            }
                        }
                    ],
                    "lengthChange": false,
                    "pagingType": "simple_numbers",
                    responsive: {
                        details: {
                            renderer: function (api, rowIdx, columns) {
                                let data = $.map(columns, function (col, i) {
                                    return col.hidden ?
                                        '<tr data-dt-row="' + col.rowIndex + '" data-dt-column="' + col.columnIndex + '">' +
                                        '<td>' + col.title + ':' + '</td> ' +
                                        '<td>' + col.data + '</td>' +
                                        '</tr>' :
                                        '';
                                }).join('');

                                return data ?
                                    $('<table/>').append(data) :
                                    false;
                            }
                        }
                    },
                    columnDefs: [
                        { responsivePriority: 1, targets: 0 }
                    ], drawCallback: function () {
                        salary.InitializeTblSalaryEvents();
                    }
                });
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.ClearFields = function () {
        $('#txtSalary').val('');
        $('#txtDays').val('');
    };

    this.GetSalary = function (employeeSalaryId) {
        $.post('../Salary/GetSalary', { employeeSalaryId: employeeSalaryId }, function (response) {

            if (response.status === 1) {
                let salaryObj = response.data;

                salary._salaryId = salaryObj.employeeSalaryId;
                $('#cmbEmployee').val(salaryObj.employeeId).selectpicker('refresh');
                $('#txtSalary').val((Math.round(salaryObj.amount * 100) / 100).toFixed(2));
                $('#txtDays').val(salaryObj.days).prop('readonly', false);
                $('#mdlSalary').modal('show');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {

        });
    };

    this.GetEmployee = function (employeeId) {
        $.post('../Employee/GetEmployee', { employeeId: employeeId }, function (response) {

            if (response.status === 1) {
                let empObj = response.data;

                $('#txtDays').prop('readonly', false);
                if (!empObj.employeeTypeDetail.dailyRate) {
                    $('#lblDays').text('Days of Absent').attr('daily-rate', false);
                }
                else {
                    $('#lblDays').text('Days of Work').attr('daily-rate', true);
                }
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {

        });
    };

    this.ComputeSalary = function (details) {
        $.post('../Salary/ComputeSalary', { details: details }, function (response) {

            if (response.status === 1) {
                let salaryObj = response.data;
                $('#txtSalary').val(ThousandsSeparators((Math.round(salaryObj.amount * 100) / 100).toFixed(2)))
                    .attr('amount', (Math.round(salaryObj.amount * 100) / 100).toFixed(2));
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {

        });
    };

    this.InitializeTblSalaryEvents = function () {
        $('.edit-salary').unbind().on("click", function () {
            let employeeSalaryId = $(this).data('salary-id');

            if (!IsEmpty(employeeSalaryId)) {
                salary.GetSalary(employeeSalaryId);
                $('#mdlSalary').modal('show');
                $('#mdlSalary').addClass('update');
                $('#btnSubmitSalary').html('<i aria-hidden="true" class="fa fa-pencil"></i> Update');
                $('#btnSubmitSalary').attr('btn-process', 'update');
            }
            else {
                MaterialNotify('Invalid Employee Salary Id specified, please refresh the page', 'warning');
            }
        });

        $('.remove-salary').unbind().on("click", function () {
            let employeeSalaryId = $(this).data('salary-id');

            if (!IsEmpty(employeeSalaryId)) {
                MaterialConfirm({
                    message: 'Are you sure you want to remove employee salary?'
                }).done(() => {
                    salary.RemoveSalary(employeeSalaryId);
                });
            }
            else {
                MaterialNotify('Invalid Employee Salary Id specified, please refresh the page', 'warning');
            }
        });
    };

    this.RemoveSalary = function (employeeSalaryId) {
        LoadingOpen();
        $.post("../Salary/RemoveSalary",
            { employeeSalaryId: employeeSalaryId },
            function (response) {
                salary.GetAllSalary();

                if (response.status === 1) {
                    MaterialNotify(response.message, 'success');
                } else {
                    MaterialNotify(response.message, 'warning', true);
                }
            }).fail(function (ex) {
                LoadingClose();
                MaterialNotify(ex.statusText, 'danger', true);
            }).done(function () {
                LoadingClose();
            });
    };

    this.GetAllEmployee = function () {
        $("#cmbEmployee").html("");
        $("#cmbEmployee").prop('disabled', true);

        $.post("../Employee/GetAllEmployee",
            function (response) {

                if (response.status === 1) {
                    if (response.data.length > 0) {
                        for (let x = 0; x < response.data.length; x++) {
                            let opt = document.createElement("option");
                            opt.value = response.data[x].employeeId;
                            opt.text = response.data[x].name;

                            $("#cmbEmployee").append(opt);
                        }

                        $("#cmbEmployee").prop('disabled', false).selectpicker('refresh');
                    }
                } else {
                    MaterialNotify(response.message, 'warning');
                }
            }).fail(function (ex) {
                MaterialNotify(ex.statusText, 'danger', true);
            }).done(function () {
            });
    };
}