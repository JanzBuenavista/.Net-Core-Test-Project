﻿$(document).ready(function () {
    var type = new Type();
    type.GetAllEmployeeType();
    type.InitializeEvents();
});

function Type() {
    var type = this;
    type._typeId = null;
    type._tblType = null;

    this.InitializeEvents = function () {
        $('#txtSearchType').keyup(function (e) {
            if (e.which === 13) {
                type._tblType.search($(this).val()).draw();
            }
            else {
                if ($(this).val().length < 1) {
                    type._tblType.search($(this).val()).draw();
                }
            }
        });

        $('#btnAddType').click(function () {
            type.ClearFields();
            $('#mdlType').modal('show');
            $('#mdlType').removeClass('update');
            $('#btnSubmitType').html('<i aria-hidden="true" class="fa fa-plus"></i> Add');
            $('#btnSubmitType').attr('btn-process', 'add');
        });

        $('#btnSubmitType').click(function () {
            let process = $(this).attr('btn-process');
            let typeObj = {
                EmployeeTypeName: $('#txtEmployeeType').val().toUpperCase(),
                Salary: $('#txtSalary').val(),
                Tax: $('#txtTax').val(),
                DailyRate: $('#chkRate').prop('checked')
            };

            if (process === 'add') {
                if (!hasNull(typeObj)) {
                    type.AddEmployeeType(typeObj);
                }
                else {
                    MaterialNotify('Please fill in all Fields', 'warning');
                }
            }
            else if (process === 'update') {
                if (!hasNull(typeObj)) {
                    typeObj.EmployeeTypeId = type._typeId;
                    type.ModifyEmployeeType(typeObj);
                }
                else {
                    MaterialNotify('Please fill in all Fields', 'warning');
                }
            }
        });
    };

    this.ModifyEmployeeType = function (details) {
        LoadingOpen();
        $.post('../Type/ModifyEmployeeType', { details: details }, function (response) {

            if (response.status === 1) {
                $('#mdlType').modal('hide');
                type.GetAllEmployeeType();
                MaterialNotify(response.message, 'success');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.AddEmployeeType = function (details) {
        LoadingOpen();
        $.post('../Type/AddEmployeeType', { details: details }, function (response) {

            if (response.status === 1) {
                $('#mdlType').modal('hide');
                type.GetAllEmployeeType();
                MaterialNotify(response.message, 'success');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.GetAllEmployeeType = function () {
        LoadingOpen();

        $.post('../Type/GetAllEmployeeType', function (response) {

            if (type._tblType !== null) {
                type._tblType.destroy();
            }

            if (response.status === 1) {
                type._tblType = $('#tblType').DataTable({
                    "paging": true,
                    "info": false,
                    "sort": true,
                    "dom": 'rtip',
                    "data": response.data,
                    "order": [[0, "desc"]],
                    "columns": [
                        {
                            data: "employeeTypeName",
                            render: function (data, type, row, meta) {
                                return '<div>' + data + '</div>' +
                                    '<div class="nav-container"><a class="edit-type" data-type-id="' + row.employeeTypeId + '" href="#">' +
                                    '<i aria-hidden="true" class="fa fa-edit"></i> Edit</a><a class="remove-type" data-type-id="' + row.employeeTypeId + '" href="#">' +
                                    '<i aria-hidden="true" class="fa fa-trash"></i> Remove</a></div>';
                            }
                        },
                        {
                            data: "salary",
                            render: function (data, type, row, meta) {
                                return '<span>' + ThousandsSeparators((Math.round(data * 100) / 100).toFixed(2)) + '</span>';
                            }
                        },
                        {
                            data: "tax",
                            render: function (data, type, row, meta) {
                                return '<span>' + ThousandsSeparators((Math.round(data * 100) / 100).toFixed(2)) + ' %</span>';
                            }
                        },
                        {
                            data: "dailyRate",
                            render: function (data, type, row, meta) {
                                if (data) {
                                    return '<span class="badge badge-success badge-pill"><b>YES</b></span>';
                                }
                                else {
                                    return '<span class="badge badge-warning badge-pill"><b>NO</b></span>';
                                }
                            }
                        }
                    ],
                    "lengthChange": false,
                    "pagingType": "simple_numbers",
                    responsive: {
                        details: {
                            renderer: function (api, rowIdx, columns) {
                                let data = $.map(columns, function (col, i) {
                                    return col.hidden ?
                                        '<tr data-dt-row="' + col.rowIndex + '" data-dt-column="' + col.columnIndex + '">' +
                                        '<td>' + col.title + ':' + '</td> ' +
                                        '<td>' + col.data + '</td>' +
                                        '</tr>' :
                                        '';
                                }).join('');

                                return data ?
                                    $('<table/>').append(data) :
                                    false;
                            }
                        }
                    },
                    columnDefs: [
                        { responsivePriority: 1, targets: 0 }
                    ], drawCallback: function () {
                        type.InitializeTblTypeEvents();
                    }
                });
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.ClearFields = function () {
        $('#txtEmployeeType').val('');
        $('#txtSalary').val('');
        $('#txtTax').val('');
        $('#chkRate').prop('checked', false);
    };

    this.GetEmployeeType = function (employeeTypeId) {
        $.post('../Type/GetEmployeeType', { employeeTypeId: employeeTypeId }, function (response) {

            if (response.status === 1) {
                let typeObj = response.data;

                type._typeId = typeObj.employeeTypeId;
                $('#txtEmployeeType').val(typeObj.employeeTypeName);
                $('#txtSalary').val(typeObj.salary);
                $('#txtTax').val(typeObj.tax);
                $('#chkRate').prop('checked', typeObj.dailyRate);
                $('#mdlType').modal('show');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {

        });
    };

    this.InitializeTblTypeEvents = function () {
        $('.edit-type').unbind().on("click", function () {
            let employeeTypeId = $(this).data('type-id');

            if (!IsEmpty(employeeTypeId)) {
                type.GetEmployeeType(employeeTypeId);
                $('#mdlType').modal('show');
                $('#mdlType').addClass('update');
                $('#btnSubmitType').html('<i aria-hidden="true" class="fa fa-pencil"></i> Update');
                $('#btnSubmitType').attr('btn-process', 'update');
            }
            else {
                MaterialNotify('Invalid Employee Type Id specified, please refresh the page', 'warning');
            }
        });

        $('.remove-type').unbind().on("click", function () {
            let employeeTypeId = $(this).data('type-id');

            if (!IsEmpty(employeeTypeId)) {
                MaterialConfirm({
                    message: 'Are you sure you want to remove employee type?'
                }).done(() => {
                    type.RemoveEmployeeType(employeeTypeId);
                });
            }
            else {
                MaterialNotify('Invalid Employee Type Id specified, please refresh the page', 'warning');
            }
        });
    };

    this.RemoveEmployeeType = function (employeeTypeId) {
        LoadingOpen();
        $.post("../Type/RemoveEmployeeType",
            { employeeTypeId: employeeTypeId },
            function (response) {
                type.GetAllEmployeeType();

                if (response.status === 1) {
                    MaterialNotify(response.message, 'success');
                } else {
                    MaterialNotify(response.message, 'warning', true);
                }
            }).fail(function (ex) {
                LoadingClose();
                MaterialNotify(ex.statusText, 'danger', true);
            }).done(function () {
                LoadingClose();
            });
    };
}