﻿$(document).ready(function () {
    var emp = new Employee();
    emp.GetAllEmployee();
    emp.GetAllEmployeeType();
    emp.InitializeEvents();
});

function Employee() {
    var emp = this;
    emp._employeeId = null;
    emp._tblEmployee = null;

    this.InitializeEvents = function () {
        $('#txtSearchEmployee').keyup(function (e) {
            if (e.which === 13) {
                emp._tblEmployee.search($(this).val()).draw();
            }
            else {
                if ($(this).val().length < 1) {
                    emp._tblEmployee.search($(this).val()).draw();
                }
            }
        });

        $('#btnAddEmployee').click(function () {
            emp.ClearFields();
            $('#mdlEmployee').modal('show');
            $('#mdlEmployee').removeClass('update');
            $('#btnSubmitEmployee').html('<i aria-hidden="true" class="fa fa-plus"></i> Add');
            $('#btnSubmitEmployee').attr('btn-process', 'add');
        });

        $('#btnSubmitEmployee').click(function () {
            let process = $(this).attr('btn-process');
            let empObj = {
                Name: $('#txtEmployeeName').val().toUpperCase(),
                Birthdate: $('#txtBirthdate').val(),
                TIN: $('#txtTIN').val(),
                EmployeeTypeId: $('#cmbEmployeeType').val()
            };

            if (process === 'add') {
                if (!hasNull(empObj)) {
                    emp.AddEmployee(empObj);
                }
                else {
                    MaterialNotify('Please fill in all Fields', 'warning');
                }
            }
            else if (process === 'update') {
                if (!hasNull(empObj)) {
                    empObj.EmployeeId = emp._employeeId;
                    emp.ModifyEmployee(empObj);
                }
                else {
                    MaterialNotify('Please fill in all Fields', 'warning');
                }
            }
        });

        $('#txtBirthdate').bootstrapMaterialDatePicker({
            weekStart: 0,
            time: false,
            format: 'MMMM DD, YYYY'
        }).on('beforeChange', function (e, date) {
        }).on('change', function (e, date) {
        });
    };

    this.ModifyEmployee = function (details) {
        LoadingOpen();
        $.post('../Employee/ModifyEmployee', { details: details }, function (response) {

            if (response.status === 1) {
                $('#mdlEmployee').modal('hide');
                emp.GetAllEmployee();
                MaterialNotify(response.message, 'success');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.AddEmployee = function (details) {
        LoadingOpen();
        $.post('../Employee/AddEmployee', { details: details }, function (response) {

            if (response.status === 1) {
                $('#mdlEmployee').modal('hide');
                emp.GetAllEmployee();
                MaterialNotify(response.message, 'success');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.GetAllEmployee = function () {
        LoadingOpen();

        $.post('../Employee/GetAllEmployee', function (response) {

            if (emp._tblEmployee !== null) {
                emp._tblEmployee.destroy();
            }

            if (response.status === 1) {
                emp._tblEmployee = $('#tblEmployee').DataTable({
                    "paging": true,
                    "info": false,
                    "sort": true,
                    "dom": 'rtip',
                    "data": response.data,
                    "order": [[0, "desc"]],
                    "columns": [
                        {
                            data: "name",
                            render: function (data, type, row, meta) {
                                return '<div>' + data + '</div>' +
                                    '<div class="nav-container"><a class="edit-emp" data-emp-id="' + row.employeeId + '" data-type-id="' + row.employeeTypeId + '" href="#">' +
                                    '<i aria-hidden="true" class="fa fa-edit"></i> Edit</a><a class="remove-emp" data-emp-id="' + row.employeeId + '" href="#">' +
                                    '<i aria-hidden="true" class="fa fa-trash"></i> Remove</a></div>';
                            }
                        },
                        {
                            data: "birthdate"
                        },
                        {
                            data: "tin"
                        },
                        {
                            data: "employeeTypeId",
                            render: function (data, type, row, meta) {
                                return '<span>' + row.employeeTypeDetail.employeeTypeName + '</span>';
                            }
                        }
                    ],
                    "lengthChange": false,
                    "pagingType": "simple_numbers",
                    responsive: {
                        details: {
                            renderer: function (api, rowIdx, columns) {
                                let data = $.map(columns, function (col, i) {
                                    return col.hidden ?
                                        '<tr data-dt-row="' + col.rowIndex + '" data-dt-column="' + col.columnIndex + '">' +
                                        '<td>' + col.title + ':' + '</td> ' +
                                        '<td>' + col.data + '</td>' +
                                        '</tr>' :
                                        '';
                                }).join('');

                                return data ?
                                    $('<table/>').append(data) :
                                    false;
                            }
                        }
                    },
                    columnDefs: [
                        { responsivePriority: 1, targets: 0 }
                    ], drawCallback: function () {
                        emp.InitializeTblEmployeeEvents();
                    }
                });
            }
        }).done(function () {
            setTimeout(function () {
                LoadingClose();
            }, 500);
        });
    };

    this.ClearFields = function () {
        $('#txtEmployeeName').val('');
        $('#txtBirthdate').val('');
        $('#txtTIN').val('');
    };

    this.GetEmployee = function (employeeId) {
        $.post('../Employee/GetEmployee', { employeeId: employeeId }, function (response) {

            if (response.status === 1) {
                let empObj = response.data;

                emp._employeeId = empObj.employeeId;
                $('#txtEmployeeName').val(empObj.name);
                $('#txtBirthdate').val(empObj.birthdate);
                $('#txtTIN').val(empObj.tin);
                $('#cmbEmployeeType').val(empObj.employeeTypeId).selectpicker('refresh');
                $('#mdlEmployee').modal('show');
            }
            else {
                MaterialNotify(response.message, 'warning');
            }
        }).done(function () {

        });
    };

    this.InitializeTblEmployeeEvents = function () {
        $('.edit-emp').unbind().on("click", function () {
            let employeeId = $(this).data('emp-id');

            if (!IsEmpty(employeeId)) {
                emp.GetEmployee(employeeId);
                $('#mdlEmployee').modal('show');
                $('#mdlEmployee').addClass('update');
                $('#btnSubmitEmployee').html('<i aria-hidden="true" class="fa fa-pencil"></i> Update');
                $('#btnSubmitEmployee').attr('btn-process', 'update');
            }
            else {
                MaterialNotify('Invalid Employee Id specified, please refresh the page', 'warning');
            }
        });

        $('.remove-emp').unbind().on("click", function () {
            let employeeId = $(this).data('emp-id');

            if (!IsEmpty(employeeId)) {
                MaterialConfirm({
                    message: 'Are you sure you want to remove employee?'
                }).done(() => {
                    emp.RemoveEmployee(employeeId);
                });
            }
            else {
                MaterialNotify('Invalid Employee Id specified, please refresh the page', 'warning');
            }
        });
    };

    this.RemoveEmployee = function (employeeId) {
        LoadingOpen();
        $.post("../Employee/RemoveEmployee",
            { employeeId: employeeId },
            function (response) {
                emp.GetAllEmployee();

                if (response.status === 1) {
                    MaterialNotify(response.message, 'success');
                } else {
                    MaterialNotify(response.message, 'warning', true);
                }
            }).fail(function (ex) {
                LoadingClose();
                MaterialNotify(ex.statusText, 'danger', true);
            }).done(function () {
                LoadingClose();
            });
    };

    this.GetAllEmployeeType = function () {
        $("#cmbEmployeeType").html("");
        $("#cmbEmployeeType").prop('disabled', true);

        $.post("../Type/GetAllEmployeeType",
            function (response) {

                if (response.status === 1) {
                    if (response.data.length > 0) {
                        for (let x = 0; x < response.data.length; x++) {
                            let opt = document.createElement("option");
                            opt.value = response.data[x].employeeTypeId;
                            opt.text = response.data[x].employeeTypeName;
                            $("#cmbEmployeeType").append(opt);
                        }

                        $("#cmbEmployeeType").prop('disabled', false).selectpicker('refresh');
                    }
                } else {
                    MaterialNotify(response.message, 'warning');
                }
            }).fail(function (ex) {
                MaterialNotify(ex.statusText, 'danger', true);
            }).done(function () {
            });
    };
}