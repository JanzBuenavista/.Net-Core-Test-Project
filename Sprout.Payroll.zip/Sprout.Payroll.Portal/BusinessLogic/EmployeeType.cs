﻿namespace Sprout.Payroll.Portal.BusinessLogic
{
    using Sprout.Payroll.Portal.Models;
    using System.Collections.Generic;
    using System.Linq;

    public class EmployeeType
    {
        private static readonly Employee employeeBLL = new Employee();

        private readonly ResponseModel response = new ResponseModel();

        private static readonly List<EmployeeTypeModel> employeeType = new List<EmployeeTypeModel>();

        private static int uniqueEmployeeTypeId = 1;

        public ResponseModel GetAllEmployeeType()
        {
            this.response.Data = employeeType;
            this.response.Message = "All employee type was loaded successfully";
            this.response.Status = 1;

            return this.response;
        }

        public ResponseModel GetEmployeeType(int employeeTypeId)
        {
            EmployeeTypeModel employeeTypeData = new EmployeeTypeModel();
            employeeTypeData = employeeType.Where(type => type.EmployeeTypeId == employeeTypeId).FirstOrDefault();

            if (employeeTypeData != null)
            {
                this.response.Data = employeeTypeData;
                this.response.Message = "Specific employee type details was loaded successfully";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Not Found: No employee type id: " + employeeTypeId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel AddEmployeeType(EmployeeTypeModel model)
        {
            EmployeeTypeModel employeeTypeData = new EmployeeTypeModel();
            employeeTypeData = employeeType.Where(type => type.EmployeeTypeName == model.EmployeeTypeName.ToUpper()).FirstOrDefault();

            if (employeeTypeData == null)
            {
                model.EmployeeTypeId = uniqueEmployeeTypeId++;
                employeeType.Add(model);

                this.response.Data = employeeType;
                this.response.Message = "New employee type details was successfully inserted";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Duplicate: Employee type name: " + model.EmployeeTypeName.ToUpper();
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel ModifyEmployeeType(EmployeeTypeModel model)
        {
            EmployeeTypeModel employeeTypeData = new EmployeeTypeModel();
            employeeTypeData = employeeType.Where(type => type.EmployeeTypeId == model.EmployeeTypeId).FirstOrDefault();

            if (employeeTypeData != null)
            {
                employeeTypeData.Salary = model.Salary;
                employeeTypeData.EmployeeTypeName = model.EmployeeTypeName;
                employeeTypeData.DailyRate = model.DailyRate;
                employeeTypeData.Tax = model.Tax;

                this.response.Data = employeeTypeData;
                this.response.Message = "Employee type details was successfully updated";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Not Found: No employee type id: " + model.EmployeeTypeId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel RemoveEmployeeType(int employeeTypeId)
        {
            EmployeeTypeModel employeeTypeData = new EmployeeTypeModel();
            employeeTypeData = employeeType.Where(type => type.EmployeeTypeId == employeeTypeId).FirstOrDefault();

            if (employeeTypeData != null)
            {
                if (employeeBLL.CheckEmployeeType(employeeTypeId) == 0)
                {
                    this.response.Data = employeeType.RemoveAll(n => n.EmployeeTypeId == employeeTypeId);
                    this.response.Message = "Remove employee type details was successfully removed";
                    this.response.Status = 1;
                }
                else
                {
                    this.response.Message = "Not Possible: This employee type it has been used by other employee's.";
                    this.response.Status = 0;
                }
            }
            else
            {
                this.response.Message = "Not Found: No employee type id: " + employeeTypeId;
                this.response.Status = 0;
            }

            return this.response;
        }
    }
}
