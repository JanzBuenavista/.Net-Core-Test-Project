﻿namespace Sprout.Payroll.Portal.BusinessLogic
{
    using Sprout.Payroll.Portal.Models;
    using System.Collections.Generic;
    using System.Linq;

    public class Employee
    {
        private static readonly EmployeeType employeeTypeBLL = new EmployeeType();

        private static readonly EmployeeSalary employeeSalaryBLL = new EmployeeSalary();

        private readonly ResponseModel response = new ResponseModel();

        private static readonly List<EmployeeModel> employee = new List<EmployeeModel>();

        private static int uniqueEmployeeId = 1;

        public ResponseModel GetAllEmployee()
        {
            this.response.Data = employee;
            this.response.Message = "All employee was loaded successfully";
            this.response.Status = 1;

            return this.response;
        }

        public ResponseModel GetEmployee(int employeeId)
        {
            EmployeeModel employeeData = new EmployeeModel();
            employeeData = employee.Where(emp => emp.EmployeeId == employeeId).FirstOrDefault();

            if (employeeData != null)
            {
                this.response.Data = employeeData;
                this.response.Message = "Specific employee details was loaded successfully";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Not Found: No employee id: " + employeeId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel AddEmployee(EmployeeModel model)
        {
            EmployeeModel employeeData = new EmployeeModel();
            employeeData = employee.Where(emp => emp.Name == model.Name.ToUpper()).FirstOrDefault();

            if (employeeData == null)
            {
                employeeData = employee.Where(emp => emp.TIN == model.TIN.ToUpper()).FirstOrDefault();

                if (employeeData == null)
                {
                    model.EmployeeId = uniqueEmployeeId++;
                    model.EmployeeTypeDetail = (EmployeeTypeModel)employeeTypeBLL.GetEmployeeType(model.EmployeeTypeId).Data;
                    employee.Add(model);

                    this.response.Data = employee;
                    this.response.Message = "New employee details was successfully inserted";
                    this.response.Status = 1;
                }
                else
                {
                    this.response.Message = "Duplicate: Employee TIN: " + model.TIN;
                    this.response.Status = 0;
                }
            }
            else
            {
                this.response.Message = "Duplicate: Employee name: " + model.Name.ToUpper();
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel ModifyEmployee(EmployeeModel model)
        {
            EmployeeModel employeeData = new EmployeeModel();
            employeeData = employee.Where(n => n.EmployeeId == model.EmployeeId).FirstOrDefault();

            if (employeeData != null)
            {
                employeeData = employee.Where(emp => emp.TIN == model.TIN.ToUpper()).FirstOrDefault();

                if (employeeData == null)
                {
                    employeeData = new EmployeeModel();
                    employeeData.Name = model.Name;
                    employeeData.Birthdate = model.Birthdate;
                    employeeData.TIN = model.TIN;
                    employeeData.EmployeeTypeId = model.EmployeeTypeId;
                    employeeData.EmployeeTypeDetail = (EmployeeTypeModel)employeeTypeBLL.GetEmployeeType(model.EmployeeTypeId).Data;

                    this.response.Data = employeeData;
                    this.response.Message = "Employee details was successfully updated";
                    this.response.Status = 1;
                }
                else
                {
                    this.response.Message = "Duplicate: Employee TIN: " + model.TIN;
                    this.response.Status = 0;
                }
            }
            else
            {
                this.response.Message = "Not Found: No employee id: " + model.EmployeeId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel RemoveEmployee(int employeeId)
        {
            EmployeeModel employeeData = new EmployeeModel();
            EmployeeSalaryModel employeeSalaryData = new EmployeeSalaryModel();

            employeeData = employee.Where(emp => emp.EmployeeId == employeeId).FirstOrDefault();

            if (employeeData != null)
            {
                if (employeeSalaryBLL.GetEmployeeSalary(employeeId) == 0)
                {
                    this.response.Data = employee.RemoveAll(n => n.EmployeeId == employeeId);
                    this.response.Message = "Remove employee details was successfully removed";
                    this.response.Status = 1;
                }
                else
                {
                    this.response.Message = "Not Possible: This employee has salary record's.";
                    this.response.Status = 0;
                }
            }
            else
            {
                this.response.Message = "Not Found: No employee id: " + employeeId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public int CheckEmployeeType(int employeeTypeId)
        {
            List<EmployeeModel> employeeData = new List<EmployeeModel>();
            employeeData = employee.Where(emp => emp.EmployeeTypeId == employeeTypeId).ToList();

            return employeeData.Count;
        }
    }
}
