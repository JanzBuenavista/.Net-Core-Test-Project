﻿namespace Sprout.Payroll.Portal.BusinessLogic
{
    using Sprout.Payroll.Portal.Models;
    using System.Collections.Generic;
    using System.Linq;

    public class EmployeeSalary
    {
        private static readonly EmployeeType employeeTypeBLL = new EmployeeType();

        private static readonly Employee employeeBLL = new Employee();

        private readonly ResponseModel response = new ResponseModel();

        private static readonly List<EmployeeSalaryModel> employeeSalary = new List<EmployeeSalaryModel>();

        private static int uniqueSalaryId = 1;

        public ResponseModel GetAllSalary()
        {
            this.response.Data = employeeSalary;
            this.response.Message = "All employee salary was loaded successfully";
            this.response.Status = 1;

            return this.response;
        }

        public ResponseModel GetSalary(int employeeSalaryId)
        {
            EmployeeSalaryModel employeeSalaryData = new EmployeeSalaryModel();
            employeeSalaryData = employeeSalary.Where(salary => salary.EmployeeSalaryId == employeeSalaryId).FirstOrDefault();

            if (employeeSalaryData != null)
            {
                this.response.Data = employeeSalaryData;
                this.response.Message = "Specific employee salary details was loaded successfully";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Not Found: No employee salary id: " + employeeSalaryId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel AddSalary(EmployeeSalaryModel model)
        {
            model.EmployeeSalaryId = uniqueSalaryId++;
            employeeSalary.Add(this.ComputeSalary(model));

            this.response.Data = employeeSalary;
            this.response.Message = "New employee salary details was successfully inserted";
            this.response.Status = 1;

            return this.response;
        }

        public EmployeeSalaryModel ComputeSalary(EmployeeSalaryModel model)
        {
            model.Employee = (EmployeeModel)employeeBLL.GetEmployee(model.EmployeeId).Data;

            if (!model.Employee.EmployeeTypeDetail.DailyRate)
            {
                model.Amount = model.Employee.EmployeeTypeDetail.Salary -
                    ((model.Employee.EmployeeTypeDetail.Salary / 22) * model.Days) -
                    (model.Employee.EmployeeTypeDetail.Salary * (model.Employee.EmployeeTypeDetail.Tax / 100));
            }
            else
            {
                model.Amount = (model.Employee.EmployeeTypeDetail.Salary * model.Days) -
                    (model.Employee.EmployeeTypeDetail.Salary * (model.Employee.EmployeeTypeDetail.Tax / 100));
            }

            return model;
        }

        public ResponseModel ModifySalary(EmployeeSalaryModel model)
        {
            EmployeeSalaryModel employeeSalaryData = new EmployeeSalaryModel();
            employeeSalaryData = employeeSalary.Where(salary => salary.EmployeeSalaryId == model.EmployeeSalaryId).FirstOrDefault();

            if (employeeSalaryData != null)
            {
                employeeSalaryData.EmployeeId = model.EmployeeId;
                employeeSalaryData.EmployeeTypeId = model.EmployeeTypeId;
                employeeSalaryData.Days = model.Days;
                employeeSalaryData.Employee = (EmployeeModel)employeeBLL.GetEmployee(model.EmployeeId).Data;

                if (!employeeSalaryData.Employee.EmployeeTypeDetail.DailyRate)
                {
                    employeeSalaryData.Amount = employeeSalaryData.Employee.EmployeeTypeDetail.Salary -
                        ((employeeSalaryData.Employee.EmployeeTypeDetail.Salary / 22) * model.Days) -
                        (employeeSalaryData.Employee.EmployeeTypeDetail.Salary * (employeeSalaryData.Employee.EmployeeTypeDetail.Tax / 100));
                }
                else
                {
                    employeeSalaryData.Amount = (employeeSalaryData.Employee.EmployeeTypeDetail.Salary * model.Days) -
                        (employeeSalaryData.Employee.EmployeeTypeDetail.Salary * (employeeSalaryData.Employee.EmployeeTypeDetail.Tax / 100));
                }

                this.response.Data = employeeSalaryData;
                this.response.Message = "Employee salary details was successfully updated";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Not Found: No employee salary id: " + model.EmployeeSalaryId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public ResponseModel RemoveSalary(int employeeSalaryId)
        {
            EmployeeSalaryModel employeeSalaryData = new EmployeeSalaryModel();
            employeeSalaryData = employeeSalary.Where(salary => salary.EmployeeSalaryId == employeeSalaryId).FirstOrDefault();

            if (employeeSalaryData != null)
            {
                this.response.Data = employeeSalary.RemoveAll(salary => salary.EmployeeSalaryId == employeeSalaryId);
                this.response.Message = "Remove employee salary details was successfully removed";
                this.response.Status = 1;
            }
            else
            {
                this.response.Message = "Not Found: No employee salary id: " + employeeSalaryId;
                this.response.Status = 0;
            }

            return this.response;
        }

        public int GetEmployeeSalary(int employeeId)
        {
            List<EmployeeSalaryModel> employeeSalaryData = new List<EmployeeSalaryModel>();
            employeeSalaryData = employeeSalary.Where(salary => salary.EmployeeId == employeeId).ToList();

            return employeeSalaryData.Count;
        }
    }
}
