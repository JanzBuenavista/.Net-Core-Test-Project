﻿namespace Sprout.Payroll.Portal.BusinessLogic
{
    using System.Text.Json;
    using System.Data;

    public class ObjectConversion
    {
        public DataTable ConvertObject(object objName)
        {
            DataTable dataObject = new DataTable();

            dataObject = (DataTable)Json.DeserializeObject(
                JsonConvert.SerializeObject(objName).ToString(),
                typeof(DataTable));

            return dataObject;
        }
    }
}
