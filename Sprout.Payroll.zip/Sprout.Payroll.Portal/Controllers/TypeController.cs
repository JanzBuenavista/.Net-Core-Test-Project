﻿namespace Sprout.Payroll.Portal.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;
    using System;

    public class TypeController : Controller
    {
        /// <summary>
        /// Information Details Model for Private Response
        /// </summary>
        private ResponseModel _response = new ResponseModel();

        private static readonly EmployeeType bll = new EmployeeType();

        public IActionResult Index()
        {
            return this.View();
        }

        [HttpPost]
        public JsonResult GetAllEmployeeType()
        {
            try
            {
                this._response = bll.GetAllEmployeeType();
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult GetEmployeeType(int employeeTypeId)
        {
            try
            {
                this._response = bll.GetEmployeeType(employeeTypeId);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult AddEmployeeType(EmployeeTypeModel details)
        {
            try
            {
                this._response = bll.AddEmployeeType(details);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult ModifyEmployeeType(EmployeeTypeModel details)
        {
            try
            {
                this._response = bll.ModifyEmployeeType(details);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult RemoveEmployeeType(int employeeTypeId)
        {
            try
            {
                this._response = bll.RemoveEmployeeType(employeeTypeId);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }
    }
}
