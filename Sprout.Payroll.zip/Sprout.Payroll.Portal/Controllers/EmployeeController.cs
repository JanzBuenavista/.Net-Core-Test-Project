﻿namespace Sprout.Payroll.Portal.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;
    using System;

    public class EmployeeController : Controller
    {
        /// <summary>
        /// Information Details Model for Private Response
        /// </summary>
        private ResponseModel _response = new ResponseModel();

        private static readonly Employee bll = new Employee();

        public IActionResult Index()
        {
            return this.View();
        }

        [HttpPost]
        public JsonResult GetAllEmployee()
        {
            try
            {
                this._response = bll.GetAllEmployee();
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult GetEmployee(int employeeId)
        {
            try
            {
                this._response = bll.GetEmployee(employeeId);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult AddEmployee(EmployeeModel details)
        {
            try
            {
                this._response = bll.AddEmployee(details);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult ModifyEmployee(EmployeeModel details)
        {
            try
            {
                this._response = bll.ModifyEmployee(details);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult RemoveEmployee(int employeeId)
        {
            try
            {
                this._response = bll.RemoveEmployee(employeeId);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        public IActionResult Error()
        {
            return this.View();
        }
    }
}
