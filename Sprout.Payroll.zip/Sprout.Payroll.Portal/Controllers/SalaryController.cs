﻿namespace Sprout.Payroll.Portal.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;
    using System;

    public class SalaryController : Controller
    {
        /// <summary>
        /// Information Details Model for Private Response
        /// </summary>
        private ResponseModel _response = new ResponseModel();

        private static readonly EmployeeSalary bll = new EmployeeSalary();

        public IActionResult Index()
        {
            return this.View();
        }

        [HttpPost]
        public JsonResult GetAllSalary()
        {
            try
            {
                this._response = bll.GetAllSalary();
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult GetSalary(int employeeSalaryId)
        {
            try
            {
                this._response = bll.GetSalary(employeeSalaryId);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult AddSalary(EmployeeSalaryModel details)
        {
            try
            {
                this._response = bll.AddSalary(details);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult ModifySalary(EmployeeSalaryModel details)
        {
            try
            {
                this._response = bll.ModifySalary(details);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult RemoveSalary(int employeeSalaryId)
        {
            try
            {
                this._response = bll.RemoveSalary(employeeSalaryId);
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }

        [HttpPost]
        public JsonResult ComputeSalary(EmployeeSalaryModel details)
        {
            try
            {
                this._response.Data = bll.ComputeSalary(details);
                this._response.Status = 1;
            }
            catch (Exception ex)
            {
                this._response.Status = 2;
                this._response.Message = ex.Message;
            }

            return Json(this._response);
        }
    }
}
