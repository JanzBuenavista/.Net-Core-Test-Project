﻿namespace Sprout.Payroll.Portal.Controllers.Api
{
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using Microsoft.IdentityModel.Tokens;
    using Sprout.Payroll.Portal.Models;
    using Sprout.Payroll.Portal.Models.Config;
    using System;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;
    using System.Text;

    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly TokenModel _tokenConfig;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginController"/> class
        /// </summary>
        /// <param name="config">App Setting Configuration</param>
        public AuthenticateController(IOptionsMonitor<TokenModel> optionsMonitor)
        {
            this._tokenConfig = optionsMonitor.CurrentValue;
        }

        private string GenerateToken(ConnectionModel user)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_tokenConfig.Secret);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim("Id", user.UserId.ToString()),
                    new Claim(JwtRegisteredClaimNames.UniqueName, user.Username),
                    new Claim(JwtRegisteredClaimNames.Sub, user.Username),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                }),
                Expires = DateTime.UtcNow.AddMinutes(10),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            return jwtTokenHandler.WriteToken(token);
        }

        [HttpGet]
        [Route("GenerateToken")]
        public IActionResult GenerateToken(int userId, string username)
        {
            return Ok(new AuthTokenModel
            {
                Token = GenerateToken(new ConnectionModel
                {
                    UserId = userId,
                    Username = username
                }),
                Success = true
            });
        }
    }
}
