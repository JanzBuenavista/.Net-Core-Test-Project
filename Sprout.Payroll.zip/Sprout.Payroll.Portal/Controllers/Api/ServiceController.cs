﻿namespace Sprout.Payroll.Portal.Controllers.Api
{
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Sprout.Payroll.Portal.BusinessLogic;
    using Sprout.Payroll.Portal.Models;

    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ServiceController : ControllerBase
    {
        /// <summary>
        /// Information Details Model for Private Response
        /// </summary>
        private ResponseModel _response = new ResponseModel();

        private static readonly EmployeeType bll = new EmployeeType();

        [HttpGet]
        [Route("GetAllEmployeeType")]
        public IActionResult GetAllEmployeeType()
        {
            this._response = bll.GetAllEmployeeType();

            if (this._response.Status == 1)
            {
                return Ok(this._response);
            }
            else
            {
                return BadRequest(this._response.Message);
            }
        }

        [HttpGet]
        [Route("GetEmployeeType")]
        public IActionResult GetEmployeeType(int employeeTypeId)
        {
            this._response = bll.GetEmployeeType(employeeTypeId);

            if (this._response.Status == 1)
            {
                return Ok(this._response);
            }
            else
            {
                return BadRequest(this._response.Message);
            }
        }

        [HttpPost]
        [Route("AddEmployeeType")]
        public IActionResult AddEmployeeType([FromBody] EmployeeTypeModel details)
        {
            this._response = bll.AddEmployeeType(details);

            if (this._response.Status == 1)
            {
                return Ok(this._response);
            }
            else
            {
                return BadRequest(this._response.Message);
            }
        }

        [HttpPut]
        [Route("ModifyEmployeeType")]
        public IActionResult ModifyEmployeeType([FromBody] EmployeeTypeModel details)
        {
            this._response = bll.ModifyEmployeeType(details);

            if (this._response.Status == 1)
            {
                return Ok(this._response);
            }
            else
            {
                return BadRequest(this._response.Message);
            }
        }

        [HttpDelete]
        [Route("RemoveEmployeeType")]
        public IActionResult RemoveEmployeeType(int employeeTypeId)
        {
            this._response = bll.RemoveEmployeeType(employeeTypeId);

            if (this._response.Status == 1)
            {
                return Ok(this._response);
            }
            else
            {
                return BadRequest(this._response.Message);
            }
        }
    }
}
